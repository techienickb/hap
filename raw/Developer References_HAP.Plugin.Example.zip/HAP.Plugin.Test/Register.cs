﻿using HAP.Web.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HAP.Plugin.Test
{
    public class Register : IRegister
    {
        public RegistrationPath[] RegisterCSS()
        {
            throw new NotImplementedException();
            /*  return new RegistrationPath[] { 
                new RegistrationPath { Path = "~/style/fullcalendar.css", LoadOn = new string[] { "/timetable.aspx" }}, 
                new RegistrationPath { Path = "~/style/timetable.css", LoadOn = new string[] { "/timetable.aspx" }} 
            };
             */
        }

        public RegistrationPath[] RegisterJSAfterHAP()
        {
            throw new NotImplementedException();
        }

        public RegistrationPath[] RegisterJSBeforeHAP()
        {
            throw new NotImplementedException();
        }

        public RegistrationPath[] RegisterJSEnd()
        {
            throw new NotImplementedException();
        }

        public RegistrationPath[] RegisterJSStart()
        {
            throw new NotImplementedException();
        }
    }
}