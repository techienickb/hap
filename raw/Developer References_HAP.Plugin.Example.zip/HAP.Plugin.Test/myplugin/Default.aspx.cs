﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HAP.Plugin.Test
{
    public partial class Default : HAP.Web.Controls.Page
    {
        public Default()
        {
            this.SectionTitle = Localize("home");
        }

        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}